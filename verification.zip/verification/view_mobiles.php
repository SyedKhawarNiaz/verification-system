<?php
include 'settings/dbconnect.php';
?>
<!DOCTYPE html>
<html lang="zxx">

    <head>
        <meta charset="UTF-8">
        <meta name="description" content="Directing Template">
        <meta name="keywords" content="Directing, unica, creative, html">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Suspicious Mobiles | Verification System</title>

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">

        
        
        <!-- Css Styles -->
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
        <link rel="stylesheet" href="css/flaticon.css" type="text/css">
        <link rel="stylesheet" href="css/nice-select.css" type="text/css">
        <link rel="stylesheet" href="css/barfiller.css" type="text/css">
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
        <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
        <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
        <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>

    <body>
        <!-- Page Preloder -->
        <div id="preloder">
            <div class="loader"></div>
        </div>

        <!-- Header Section Begin -->
        <?php
        include 'components/menu.php';
        ?>
        <!-- Header Section End -->

        <!-- Breadcrumb Begin -->
        <div class="breadcrumb-area set-bg" data-setbg="img/breadcrumb/breadcrumb-normal.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="breadcrumb__text">
                            <h2>Suspicious Mobiles</h2>
                            <div class="breadcrumb__option">
                                <a href="index.php"><i class="fa fa-home"></i> Home</a>
                                <span>Suspicious Mobiles</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Breadcrumb End -->

        <br><br><br>
        <div class="container">
            <div class="row">
                <!-- ============================================================== -->
                <!-- valifation types -->
                <!-- ============================================================== -->
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="card">
                        <div class="card-body">
                            <form  method="get">
                                <div class="form-group row">
                                    <label class="col-12 col-sm-3 col-form-label text-sm-right">Search Verification Status</label>
                                    <div class="col-12 col-sm-8 col-lg-6">
                                        <select class="form-control" name="verification_status" id="verification_status" onchange="form.submit()">
                                            <option value="0">All</option>
                                            <option value="2" <?php
                                            if (isset($_GET['verification_status'])) {
                                                if ($_GET['verification_status'] == 2) {
                                                    echo 'selected=""';
                                                }
                                            }
                                            ?>>Lost</option>
                                            <option value="3"
                                            <?php
                                            if (isset($_GET['verification_status'])) {
                                                if ($_GET['verification_status'] == 3) {
                                                    echo 'selected=""';
                                                }
                                            }
                                            ?>
                                                    >Stolen</option>
                                        </select>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end valifation types -->
                <!-- ============================================================== -->
            </div>

            <div class="row">
                <!-- ============================================================== -->
                <!-- data table  -->
                <!-- ============================================================== -->
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Suspicious Mobiles List</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="example" class="table table-striped table-bordered second" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Category</th>
                                            <th>Code</th>
                                            <th>Status</th>
                                            <th>Detail</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                       if(isset($_GET['verification_status'])){
                                        if($_GET['verification_status']!=0){
                                            $query = 'SELECT * FROM `complain` as cm inner JOIN category as c on cm.cat_id=c.cat_id WHERE  c.cat_id=4 and complain_status='.$_GET['verification_status'];
                                        }else{
                                            $query = 'SELECT * FROM `complain` as cm inner JOIN category as c on cm.cat_id=c.cat_id WHERE complain_status!=1 and c.cat_id=4';
                                        }
                                    }else{
                                        $query = 'SELECT * FROM `complain` as cm inner JOIN category as c on cm.cat_id=c.cat_id WHERE complain_status!=1 and c.cat_id=4';
                                    }

                                        $result = mysqli_query($con, $query);
                                        if (mysqli_num_rows($result) > 0) {
                                            $sr = 1;
                                            while ($row = mysqli_fetch_array($result)) {
                                                ?>
                                                <tr>
                                                    <td><?= $sr . '.' ?></td>
                                                    <td><?= $row['cat_name'] ?></td>
                                                    <td><?= $row['product_code'] ?></td>
                                                    <td><?php
                                                        if ($row['complain_status'] == 3) {
                                                            echo 'Stolen';
                                                        } else if ($row['complain_status'] == 2) {
                                                            echo 'Lost';
                                                        } else {
                                                            echo 'Cleared';
                                                        }
                                                        ?></td>
                                                    
                                                    <td>
                                                        <a href='javascript:void(0)' class="btn btn-danger detail" data-id="<?php echo $row['complain_id'];?>" data-target="#detail" data-toggle="modal"> View Detail</a></td>
                                                </tr>
                                                <?php
                                                $sr++;
                                            }
                                        } else {
                                            ?>
                                            <tr >
                                                <td colspan="4"><center>No Verifications Found</center></td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>#</th>
                                            <th>Category</th>
                                            <th>Code</th>
                                            <th>Status</th>
                                            <th>Detail</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end data table  -->
                <!-- ============================================================== -->
            </div>
        </div>
      
    <div class="modal" id="detail">
	<div class="modal-dialog" style="width:420px">
	<div class="modal-content">
	<div class="modal-header"> 
        
		</div>
		
		<div class="body" id="get_detail">
        
        </div><br>
            <div class="modal-fotter">
		   <button type="button" class=" btn bg-danger text-light" data-dismiss="modal" 
		    style="float:right; margin-right:10px">Close</button>
		</div><br>
		</div>
        </div>
      </div>
                <script src="js/jquery-3.3.1.min.js"></script>
        <script type="text/javascript">
        $(document).ready(function(){
            $(".detail").click(function(){
        var id= $(this).data('id');        
                
                
            $.ajax({
			url: "get_record.php",
			type: 'post',
			data: {id:id
			},
			success: function(data,status){
				$('#get_detail').html(data);
			},
			});
                });
        
            });
        </script>
        <br><br><br>
        <!-- Newslatter Section Begin -->
        <?php
        include 'components/footer.php';
        ?>
        <!-- Footer Section End -->

        <!-- Js Plugins -->
        <script src="js/bootstrap.min.js"></script>
<!--        <script src="js/jquery.nice-select.min.js"></script>-->
        <script src="js/jquery-ui.min.js"></script>
        <script src="js/jquery.nicescroll.min.js"></script>
        <script src="js/jquery.barfiller.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/jquery.slicknav.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/main.js"></script>
    </body>

</html>