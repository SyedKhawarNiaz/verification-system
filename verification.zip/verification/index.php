<?php
include 'settings/dbconnect.php';
?>
<!DOCTYPE html>
<html lang="zxx">

    <head>
        <meta charset="UTF-8">
        <meta name="description" content="Directing Template">
        <meta name="keywords" content="Directing, unica, creative, html">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Verification System</title>

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <!-- Css Styles -->
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
        <link rel="stylesheet" href="css/flaticon.css" type="text/css">
        <link rel="stylesheet" href="css/nice-select.css" type="text/css">
        <link rel="stylesheet" href="css/barfiller.css" type="text/css">
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
        <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
        <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
        <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
        <link rel="stylesheet" href="css/style.css" type="text/css">
        <link rel="stylesheet" href="admin/assets/toastr.min.css">
    </head>
	
    <body>
        <!-- Page Preloder -->
        <div id="preloder">
            <div class="loader"></div>
        </div>

        <!-- Header Section Begin -->
        <?php
        include 'components/menu.php';
        ?>
        <!-- Header Section End -->
<div class="contain" style="height: 300px;">
 
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    

    <!-- Wrapper for slides -->
    <div class="carousel-inner" >
      <div class="item active">
        <img src="img/aa.jpg" alt="Los Angeles" style="width:100%;height:630px">
      </div>

      <div class="item">
        <img src="img/aaa.jpg" alt="Chicago" style="width:100%;height:630px">
      </div>
    
      <div class="item">
        <img src="img/car.jpg" alt="New york" style="width:100%;height:630px">
      </div>
    </div>

    <!-- Left and right controls -->
    
  </div>
</div>
                    
    <!-- Hero Section Begin -->
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="hero__text">
                            <div class="section-title">
                                <h2>Verify Your Devices Before Purchase</h2>
                                <p>You are accessing from <?= $_SERVER['REMOTE_ADDR'] ?> IP</p>
                            </div>
                            <div class="hero__search__form" style="background: rgba(255, 255, 255, 0.1);">
                                <form method="get">
                                    <input type="text"
                                    <?php
                                    if (isset($_GET['code'])) {
                                        ?>
                                               value="<?= $_GET['code'] ?>"
                                               <?php
                                           }
                                           ?>
                                           style="width:62.2%; color:black; font-size: 16px;" id="code" name="code" required="" placeholder="Please Select Category First" pattern="" maxlength="">
                                    <div class="select__option">
                                        <select id="cat" name="cat" onchange="return placeholder()">
                                            <option value="">Choose Categories</option>
                                            <?php
                                            $query = 'SELECT * FROM `category` WHERE cat_status=1';
                                            $result = mysqli_query($con, $query);
                                            if (mysqli_num_rows($result) > 0) {
                                                while ($row = mysqli_fetch_array($result)) {
                                                    ?>
                                                    <option value="<?= $row['cat_id'] ?>"
                                                    <?php
                                                    if (isset($_GET['cat'])) {
                                                        if ($row['cat_id'] == $_GET['cat']) {
                                                            echo 'selected=""';
                                                        }
                                                    }
                                                    ?>

                                                            ><?= $row['cat_name'] ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                        </select>
                                    </div>
                                    <button type="submit" onclick="return valid()">Verify Now</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<br><br><br><br>
        <!-- Hero Section End -->

        <!-- Categories Section Begin -->

        <!-- Categories Section End -->

        <!-- Most Search Section Begin -->

        <!-- Most Search Section End -->

        <!-- Work Section Begin -->
        <?php
        if (isset($_GET['code'])) {
            ?>
            <section class="work spad">
                <div class="container">

                    <div class="row">
                        <div class="col-lg-2 col-md-4">

                        </div>
                        <div class="col-lg-8 col-md-6">
                            <div class="work__item">
                                <div class="work__item__number">Result .</div>
                                <?php
                                $query = 'SELECT * FROM `complain` as p INNER JOIN `category` as c on p.cat_id=c.cat_id WHERE p.product_code="' . $_GET['code'] . '" && p.cat_id="' . $_GET['cat'] . '"';
                                $result = mysqli_query($con, $query);
                                if (mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_array($result)) {
                                        if (isset($_SESSION['USERID'])) {
                                            $history = 'insert into history(`user_id`,`product_id`,`date`) values("' . $_SESSION['USERID'] . '","' . $row['complain_id'] . '","' . date('Y-m-d') . '") ';
                                            mysqli_query($con, $history);
                                        }
                                        ?>
                                        <?php
                                        if ($row['complain_status'] == 1) {
                                            ?>
                                            <h5 style="color: green">PRODUCT CLEARED</h5>
                                            <?php
                                        }
                                        ?>
                                        <?php
                                        if ($row['complain_status'] == 3) {
                                            ?>
                                            <h5 style="color: red">PRODUCT STOLEN</h5>
                                            <?php
                                        }
                                        ?>
                                        <?php
                                        if ($row['complain_status'] == 2) {
                                            ?>
                                            <h5 style="color: red">PRODUCT LOST</h5>
                                            <?php
                                        }
                                        ?>
                                        <p><strong>Code:</strong> <?= $_GET['code'] ?> <strong>Category:</strong><?= $row['cat_name'] ?></p>
                                        <?php
                                    }
                                } else {
                                    ?>
                                    <h5>No Record Found</h5>
                                    <?php
                                    $query = 'SELECT * FROM `category` where cat_id=' . $_GET['cat'];
                                    $result = mysqli_query($con, $query);
                                    $row = mysqli_fetch_array($result);
                                    ?>
                                    <p><strong>Code:</strong><?= $_GET['code'] ?> / <strong>Category:</strong><?= $row['cat_name'] ?></p>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <?php
        }
        ?>
        <section class="work spad">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="work__item">
                            <div class="work__item__number">01.</div>
                            <img src="img/work/car.png" alt="">
                            <h5>Suspicious Cars</h5><br>
                            <a href="view_cars.php" class="primary-btn">View List</a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="work__item">
                            <div class="work__item__number">02.</div>
                            <img src="img/work/bike.png" alt="">
                            <h5>Suspicious Bikes</h5><br>
                            <a href="view_bikes.php" class="primary-btn">View List</a>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="work__item">
                            <div class="work__item__number">03.</div>
                            <img src="img/work/mobile.png" alt="">
                            <h5>Suspicious Mobiles</h5><br>
                            <a href="view_mobiles.php" class="primary-btn">View List</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Work Section End -->

        <!-- Feature Location Section Begin -->

        <!-- Feature Location Section End -->

        <!-- Testimonial Section Begin -->

        <!-- Testimonial Section End -->

        <!-- Blog Section Begin -->

        <!-- Blog Section End -->

        <!-- Newslatter Section Begin -->
        <?php
        include 'components/footer.php';
        ?>
        <!-- Footer Section End -->

        <!-- Js Plugins -->
        <script src="js/jquery-3.3.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.nice-select.min.js"></script>
        <script src="js/jquery-ui.min.js"></script>
        <script src="js/jquery.nicescroll.min.js"></script>
        <script src="js/jquery.barfiller.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/jquery.slicknav.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/main.js"></script>
        <script src="admin/assets/toastr.min.js"></script>
        <script>
                                        function valid() {
                                            var select = $('#cat').val();
                                            if (select == 0) {
                                                toastr.options = {
                                                    "closeButton": true,
                                                    "showMethod": "fadeIn",
                                                    "hideMethod": "fadeOut"
                                                }
                                                toastr.error('Category Not Selected!');
                                                return false;
                                            }
                                        }
                                        function placeholder() {
                                            var cat = $('#cat').val();
                                            if (cat == 4) {
                                                $("#code").attr("placeholder", "Enter Your 15 digit IMEI Of Mobile i.e. 123456789101234").val("").focus().blur();
                                                $("#code").attr("pattern", "[0-9]{15}").val("").focus().blur();
                                                $("#code").attr("maxlength", "15").val("").focus().blur();
                                            }
                                            if (cat == 5) {
                                                $("#code").attr("placeholder", "Enter Your 17 digit Car Chassis Number i.e. A2N45T789MU1234AC").val("").focus().blur();
                                                $("#code").attr("pattern", "[A-Z0-9]{17}").val("").focus().blur();
                                                $("#code").attr("maxlength", "17").val("").focus().blur();
                                            }
                                            if (cat == 6) {
                                                $("#code").attr("placeholder", "Enter Your 17 digit Bike Chassis Number i.e. 54TRET56DF89E64Y").val("").focus().blur();
                                                $("#code").attr("pattern", "[A-Z0-9]{17}").val("").focus().blur();
                                                $("#code").attr("maxlength", "17").val("").focus().blur();
                                            }
                                        }
        </script>
    </body>

</html>