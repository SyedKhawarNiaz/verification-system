<style>

    .sticky{
        background-color:white;
    }
	.header{
		position: fixed;top: 0; width: 100%;
		background: white;
	}
</style>
<header class="header" id="myHeader" >
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-4 col-md-4">
                <div class="header__logo">
                    <a href="index.php"><h4 style="color: #323232;">ELECTRONICS VERIFICATION</h4></a>
                </div>
            </div>
            <div class="col-lg-8 col-md-8">
                <div class="header__nav">
                    <nav class="header__menu mobile-menu" style="background-color:white">
                        <ul>
                            <li ><a href="index.php" style="color: #323232">Home</a></li>
                            <?php
                            if (isset($_SESSION['USERID'])) {
                                ?>
                                <li><a href="history.php" style="color: #323232">My Complaints</a></li>
                                <li><a href="complain.php" style="color: #323232">Make Complain</a></li>
                                <li><a href="logout.php"style="color: #323232">Logout</a></li>
                                <?php
                            } else {
                                ?>
                                <li><a href="register.php"style="color: #323232">Register</a></li>
                                <li><a href="login.php"style="color: #323232">Sign In</a></li>
                                <?php
                            }
                            ?>
                            <li><a href="contact.php"style="color: #323232">Contact Us</a></li>
                            <li><a href="about.php"style="color: #323232">About Us</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <div id="mobile-menu-wrap"></div>
    </div>
</header>
<script>
window.onscroll = function() {myFunction()};

// Get the header
var header = document.getElementById("myHeader");

// Get the offset position of the navbar
var sticky = header.offsetTop;

// Add the sticky class to the header when you reach its scroll position. Remove "sticky" when you leave the scroll position
function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
</script>