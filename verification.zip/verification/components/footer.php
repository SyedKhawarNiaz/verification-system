<?php
$con = mysqli_connect('localhost', 'root', '', 'verify');
if (isset($_REQUEST['submit'])) {
    $query = 'INSERT INTO `subscription`(`email`) VALUES ("' . $_REQUEST['email'] . '")';
    mysqli_query($con, $query);
}
?>

<section class="newslatter">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="newslatter__text">
                    <h3>Subscribe Newsletter</h3>
                    <p>Subscribe to our newsletter and don’t miss anything</p>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <form method="post" class="newslatter__form">
                    <input type="text" required="" placeholder="Your email" name="email" data-error="Valid email is required.">
                    <button type="submit" name="submit">Subscribe</button>
                </form>
            </div>
        </div>
    </div>
</section>
<!-- Newslatter Section End -->

<!-- Footer Section Begin -->
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="footer__about">
                    <div class="footer__about__logo">
                        <a href="index.php"><h2 style="color: Black">ELECTRONICS VERIFICATION</h2></a>
                    </div>
                    <p>Challenging the way things have always been done can lead to creative new options that reward
                        you.</p>
                </div>
            </div>
            <div class="col-lg-4 offset-lg-1 col-md-6">
                <div class="footer__address">
                    <ul>
                        <li>
                            <span>Call Us:</span>
                            <p>(+92) 311-661-4334</p>
                        </li>
                        <li>
                            <span>Email:</span>
                            <p>aligroup@gmail.com</p>
                        </li>
                        <li>
                            <span>Fax:</span>
                            <p>(+12) 345-678-910</p>
                        </li>
                        <li>
                            <span>Connect Us:</span>
                            <div class="footer__social">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-skype"></i></a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 offset-lg-1 col-md-6">
                <div class="footer__widget">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                        <li><a href="login.php">Sign In</a></li>
                    </ul>
                    <ul>
                        <li><a href="#">Locations</a></li>
                        <li><a href="#">Explore Categories</a></li>
                        <li><a href="#">Making Complaints</a></li>
                        <li><a href="history.php">History</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="footer__copyright">

                    <div class="footer__copyright__links">
                        <a href="#">Terms</a>
                        <a href="#">Privacy Policy</a>
                        <a href="#">Cookie Policy</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>