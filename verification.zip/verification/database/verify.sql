-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2021 at 06:03 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `verify`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `address` varchar(1200) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 2 COMMENT '1=main admin 2=sub admin',
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `pass`, `address`, `type`, `status`) VALUES
(1, 'Ali Raza', 'admin@gmail.com', 'admin111', '130/9-L Thana Dera Raheem, Sahiwal', 1, 1),
(3, 'Aroma Anwar', 'test@aroma.com', '12345678', 'Fareed town, Sahiwal', 2, 1),
(4, 'Abdul Moiz', 'test@moiz.com', 'moiz1122', 'Fateh Sher Colony, Sahiwal', 2, 1),
(6, 'Ali Ch', 'Ali31@gmail.com', 'raza3131', '147/9-L, Sahiwal, Punjab', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(100) NOT NULL,
  `cat_status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`, `cat_status`) VALUES
(4, 'Mobile', 1),
(5, 'Car', 1),
(6, 'Bike', 1);

-- --------------------------------------------------------

--
-- Table structure for table `complain`
--

CREATE TABLE `complain` (
  `complain_id` int(11) NOT NULL,
  `user_id` varchar(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `complain_description` varchar(1000) NOT NULL,
  `proof_img` varchar(100) NOT NULL,
  `proof_img2` varchar(700) NOT NULL,
  `proof_img3` varchar(800) NOT NULL,
  `mark_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '3=Cleared 2=Reject 1=Approve 0=Pending',
  `complain_status` tinyint(1) NOT NULL COMMENT '3=Stolen 2=Lost'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complain`
--

INSERT INTO `complain` (`complain_id`, `user_id`, `cat_id`, `product_code`, `complain_description`, `proof_img`, `proof_img2`, `proof_img3`, `mark_status`, `complain_status`) VALUES
(1, '1', 5, '78654982456787892', 'sdfcsdfs', 'Harry_Potter.png', '', '', 3, 2),
(2, '1', 5, '05221325222437821', 'sdfcsdfs fsdftrwer', 'Harry_Potter.png', '', '', 2, 2),
(3, '1', 5, '12345678980675432', 'abc dfgasju wjrjwetwejk yrweiretemd hdasfsdnmfnfhf', 'neonbrand-uq5RMAZdZG4-unsplash.jpg', '', '', 1, 2),
(4, '1', 6, '12345654321789012', 'qwertytry dfhdgerootryoery', 'microkernel.jpg', '', '', 1, 2),
(5, '1', 4, '123456789908765', 'adjsfjsdgdkg sfhdkjgsd,sdn', 'inaki-del-olmo-NIJuEQw0RKg-unsplash.jpg', '', '', 2, 3),
(6, '1', 5, '12345671234562343', 'w2erte e rerterytry', 'artificial-intelligence-3382507_1920.jpg', '', '', 0, 3),
(7, '1', 5, '12345678090123455', 'sfdgdfgsd fdffhdf', 'component-basedsoftwareengineering-18-638.jpg', '', '', 0, 3),
(8, '2', 5, '12334567834252223', 'gshhsf jdhadfhj hhnkns', 'ola-syrocka-JAX93ZrczTM-unsplash.jpg', '', '', 3, 3),
(9, '1', 4, '123456789123456', 'aaaa', 'WhatsApp Image 2021-06-05 at 8.51.25 AM.jpeg', 'new logo.png', 'new logo.png', 0, 2),
(11, '3', 5, '12345678912345688', 'ttt', 'logo 1-01.png', 'logo 1-01.png', 'ezgif.com-gif-maker (1).jpg', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `contact_message`
--

CREATE TABLE `contact_message` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `msg` varchar(1200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_message`
--

INSERT INTO `contact_message` (`id`, `name`, `email`, `phone`, `msg`) VALUES
(1, 'tahir ioqbalk', 'tahir@test.com', '0798', 'hnkjhbkjlbkj'),
(2, 'Muhammad Ali', 'ali448@gmail.com', '03039021030', 'rai 2526748');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `history_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`history_id`, `user_id`, `product_id`, `date`) VALUES
(20, 1, 5, '2021-04-01'),
(21, 1, 4, '2021-04-01'),
(22, 1, 6, '2021-04-01'),
(23, 1, 6, '2021-04-01'),
(24, 1, 6, '2021-04-01'),
(25, 1, 6, '2021-04-01'),
(26, 1, 6, '2021-04-01'),
(27, 1, 6, '2021-04-01'),
(28, 1, 6, '2021-04-01'),
(29, 1, 6, '2021-04-01'),
(30, 1, 6, '2021-04-01'),
(31, 1, 5, '2021-04-01');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `product_code` varchar(50) NOT NULL,
  `verif_status` tinyint(1) NOT NULL COMMENT '1-cleared 3=Stolen 2=lost',
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `cat_id`, `product_code`, `verif_status`, `status`) VALUES
(1, 4, '05221325222', 1, 1),
(2, 4, '2342asc32', 2, 1),
(3, 4, '2342asc32', 2, 1),
(4, 6, 'asdasd3242342', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `reg_user`
--

CREATE TABLE `reg_user` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `id_card` varchar(1000) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 2,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reg_user`
--

INSERT INTO `reg_user` (`user_id`, `name`, `email`, `phone`, `id_card`, `pass`, `address`, `type`, `status`) VALUES
(1, 'ali ch', 'test@gmail.com', '03008979867', '3650276112151', 'test1234', 'Sahiwal', 2, 1),
(2, 'Muhammad Ali', 'mshafqat448@gmail.com', '03039021030', '3570276112162', '12345566', '130/9-L, Sahiwal, Punjab', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `subscription`
--

CREATE TABLE `subscription` (
  `sub_id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `complain`
--
ALTER TABLE `complain`
  ADD PRIMARY KEY (`complain_id`);

--
-- Indexes for table `contact_message`
--
ALTER TABLE `contact_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`history_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reg_user`
--
ALTER TABLE `reg_user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `subscription`
--
ALTER TABLE `subscription`
  ADD PRIMARY KEY (`sub_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `complain`
--
ALTER TABLE `complain`
  MODIFY `complain_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `contact_message`
--
ALTER TABLE `contact_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `reg_user`
--
ALTER TABLE `reg_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `subscription`
--
ALTER TABLE `subscription`
  MODIFY `sub_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
