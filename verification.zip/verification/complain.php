<?php
include 'settings/dbconnect.php';
if (isset($_REQUEST['sub_btn'])) {
    $chcek_query = 'SELECT * FROM `complain` where `product_code`="' . $_REQUEST['code'] . '" && cat_id="' . $_REQUEST['category'] . '"';
    $result = mysqli_query($con, $chcek_query);
    if (mysqli_num_rows($result) > 0) {
        header('location:complain.php?already_added');
    } else {
                $path = $_FILES["img"]["name"];
                $path2 = $_FILES["img2"]["name"];
                $path3 = $_FILES["img3"]["name"];

        $query = 'INSERT INTO `complain`(`user_id`,`cat_id`, `product_code`, `complain_description`, `proof_img`, `proof_img2`, `proof_img3`, `complain_status`) VALUES ("' . $_SESSION['USERID'] . '","' . $_REQUEST['category'] . '","' . $_REQUEST['code'] . '","' . $_REQUEST['msg'] . '","' . $path . '","' . $path2 . '","' . $path3 . '","' . $_REQUEST['status'] . '")';
//    die($query);
        move_uploaded_file($_FILES["img"]["tmp_name"], "admin/complaints/" . $_FILES["img"]["name"]);
         move_uploaded_file($_FILES["img2"]["tmp_name"], "admin/complaints/" . $_FILES["img2"]["name"]);
         move_uploaded_file($_FILES["img3"]["tmp_name"], "admin/complaints/" . $_FILES["img3"]["name"]);
        mysqli_query($con, $query);
        header('location:history.php?complain_sub');
    }
}
?>
<!DOCTYPE html>
<html lang="zxx">

    <head>
        <meta charset="UTF-8">
        <meta name="description" content="Directing Template">
        <meta name="keywords" content="Directing, unica, creative, html">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Complain | Verification System</title>

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">

        <!-- Css Styles -->
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
        <link rel="stylesheet" href="css/flaticon.css" type="text/css">
        <link rel="stylesheet" href="css/nice-select.css" type="text/css">
        <link rel="stylesheet" href="css/barfiller.css" type="text/css">
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
        <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
        <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
        <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
        <link rel="stylesheet" href="css/style.css" type="text/css">
        <link rel="stylesheet" type="text/css" href="toster/toastr.min.css">
    </head>

    <body>
        <!-- Page Preloder -->
        <div id="preloder">
            <div class="loader"></div>
        </div>

        <!-- Header Section Begin -->
        <?php
        include 'components/menu.php';
        ?>
        <!-- Header Section End -->

        <!-- Breadcrumb Begin -->
        <div class="breadcrumb-area set-bg" data-setbg="img/breadcrumb/breadcrumb-normal.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="breadcrumb__text">
                            <h2>Make Complaint</h2>
                            <div class="breadcrumb__option">
                                <a href="#"><i class="fa fa-home"></i> Home</a>
                                <span>Make Complaint</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Breadcrumb End -->

        <!-- Contact Section Begin -->
        <section class="contact spad">
            <div class="container">

                <div class="row">

                    <div class="col-lg-8 col-md-8 offset-lg-2 offset-md-2">
                        <form method="post" class="contact__form" enctype="multipart/form-data">
                            <div class="row" style="margin-bottom:20px;">
                                <div class="col-lg-12 col-md-12" >
                                    <select name="category" id="category" onchange="return placeholder()" style="width: 100% !important; height:50px; background-color: #f9f9f9; border-radius: 2px; padding-left: 24px; color: #777C81; border: 1px solid #e5e5e5; border-radius: 2px;">
                                        <option  value="">Choose Category</option>
                                        <?php
                                        $query = 'SELECT * FROM `category` WHERE cat_status=1';
                                        $result = mysqli_query($con, $query);
                                        if (mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_array($result)) {
                                                ?>
                                                <option value="<?= $row['cat_id'] ?>"
                                                <?php
                                                if (isset($_GET['cat'])) {
                                                    if ($row['cat_id'] == $_GET['cat']) {
                                                        echo 'selected=""';
                                                    }
                                                }
                                                ?>

                                                        ><?= $row['cat_name'] ?></option>
                                                        <?php
                                                    }
                                                }
                                                ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-12 col-md-12">
                                    <input type="text" id="code" name="code" placeholder="Enter Specific Code" required="required" pattern="" maxlength="">
                                </div>
                            </div>
                            <div class="row" style="margin-bottom:20px;">
                                <div class="col-lg-12 col-md-12">
                                    <select class="form-control" id="status" name="status"  style="width: 100% !important; height:50px; background-color: #f9f9f9; border-radius: 2px; padding-left: 24px; color: #777C81; border: 1px solid #e5e5e5; border-radius: 2px;">
                                        <option value="0">Select Status</option>
                                        <option value="3">Stolen</option>
                                        <option value="2">Lost</option>
                                    </select>
                                </div>
                            </div>
                            <textarea placeholder="Complaint Description" id="msg" name="msg"></textarea>
                            <div class="row" style="margin-top: -20px;">
                                <div class="col-lg-12 col-md-12">
                                    <input type="file" id="img" name="img" style="padding-top: 10px;" required>
                                </div>
                                <div class="col-lg-12 col-md-12">
                                    <input type="file" id="img2" name="img2" style="padding-top: 10px;" required>
                                </div>
                                <div class="col-lg-12 col-md-12">
                                    <input type="file" id="img3" name="img3" style="padding-top: 10px;" required>
                                </div>
                            </div>
                            <button type="submit" onclick="return valid()" name="sub_btn" class="site-btn">SUBMIT COMPLAINT</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!-- Contact Section End -->

        <!-- Newslatter Section Begin -->
        <?php
        include 'components/footer.php';
        ?>
        <!-- Footer Section End -->

        <!-- Js Plugins -->
        <script src="js/jquery-3.3.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

        <script src="js/jquery-ui.min.js"></script>
        <script src="js/jquery.nicescroll.min.js"></script>
        <script src="js/jquery.barfiller.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/jquery.slicknav.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/main.js"></script>
        <script src="toster/toastr.min.js"></script>
        <script>
                                function valid() {
                                    var category, code, img, msg, status;
                                    var temp = 1;
                                    category = $('#category').val();
                                    code = $('#code').val();
                                    img = $('#img').val();
                                    msg = $('#msg').val();
                                    status = $('#status').val();
                                    $('#category').css('border', 'solid 1px grey');
                                    $('#code').css('border', 'solid 1px grey');
                                    $('#img').css('border', 'solid 1px grey');
                                    $('#msg').css('border', 'solid 1px grey');
                                    $('#status').css('border', 'solid 1px grey');
                                    if (category == '') {
                                        $('#category').css('border', 'solid 1px red');
                                        temp++;
                                    }
                                    if (code == '') {
                                        $('#code').css('border', 'solid 1px red');
                                        temp++;
                                    }
                                    if (img == '') {
                                        $('#img').css('border', 'solid 1px red');
                                        temp++;
                                    }
                                    if (msg == '') {
                                        $('#msg').css('border', 'solid 1px red');
                                        temp++;
                                    }
                                    if (status == '') {
                                        $('#status').css('border', 'solid 1px red');
                                        temp++;
                                    }
                                    if (temp != 1) {
                                        return false;
                                    }
                                }

                                function placeholder() {
                                    var cat = $('#category').val();
                                    if (cat == 4) {
                                        $("#code").attr("placeholder", "Enter 15 digits IMEI Of Mobile").val("").focus().blur();
                                        $("#code").attr("pattern", "[0-9]{15}").val("").focus().blur();
                                        $("#code").attr("maxlength", "15").val("").focus().blur();
                                    }
                                    if (cat == 5) {
                                        $("#code").attr("placeholder", "Enter 17 digits Car Chassis Number").val("").focus().blur();
                                        $("#code").attr("pattern", "[A-Z0-9]{17}").val("").focus().blur();
                                        $("#code").attr("maxlength", "17").val("").focus().blur();
                                    }
                                    if (cat == 6) {
                                        $("#code").attr("placeholder", "Enter 17 digits Bike Chassis Number").val("").focus().blur();
                                        $("#code").attr("pattern", "[A-Z0-9]{17}").val("").focus().blur();
                                        $("#code").attr("maxlength", "17").val("").focus().blur();
                                    }
                                }

        </script>
        <?php
        if (isset($_GET['complain_sub'])) {
            ?>
            <script type="text/javascript">
                toastr.options = {
                    "closeButton": true,
                    "showMethod": "fadeIn",
                    "hideMethod": "fadeOut"
                }
                toastr.success('Complaint submitted successfully wait for Approval!');
            </script>
            <?php
        }
        ?>

        <?php
        if (isset($_GET['already_added'])) {
            ?>
            <script type="text/javascript">
                toastr.options = {
                    "closeButton": true,
                    "showMethod": "fadeIn",
                    "hideMethod": "fadeOut"
                }
                toastr.error('Complaint Already submitted!');
            </script>
            <?php
        }
        ?>
    </body>
</html>