<?php
include 'settings/dbconnect.php';
if (isset($_REQUEST['sub_btn'])) {
    $query = 'INSERT INTO `contact_message`( `name`, `email`, `phone`, `msg`) VALUES ("' . $_REQUEST['f_name'] . ' ' . $_REQUEST['l_name'] . '","' . $_REQUEST['email'] . '","' . $_REQUEST['phone'] . '","' . $_REQUEST['msg'] . '")';
    mysqli_query($con, $query);
    header('location:contact.php?sent');
}
?>
<!DOCTYPE html>
<html lang="zxx">

    <head>
        <meta charset="UTF-8">
        <meta name="description" content="Directing Template">
        <meta name="keywords" content="Directing, unica, creative, html">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Contact | Verification System</title>

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">

        <!-- Css Styles -->
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
        <link rel="stylesheet" href="css/flaticon.css" type="text/css">
        <link rel="stylesheet" href="css/nice-select.css" type="text/css">
        <link rel="stylesheet" href="css/barfiller.css" type="text/css">
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
        <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
        <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
        <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
        <link rel="stylesheet" href="css/style.css" type="text/css">
        <link rel="stylesheet" type="text/css" href="toster/toastr.min.css">
    </head>

    <body>
        <!-- Page Preloder -->
        <div id="preloder">
            <div class="loader"></div>
        </div>

        <!-- Header Section Begin -->
        <?php
        include 'components/menu.php';
        ?>
        <!-- Header Section End -->

        <!-- Breadcrumb Begin -->
        <div class="breadcrumb-area set-bg" data-setbg="img/breadcrumb/breadcrumb-normal.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="breadcrumb__text">
                            <h2>Contact Us</h2>
                            <div class="breadcrumb__option">
                                <a href="#"><i class="fa fa-home"></i> Home</a>
                                <span>Contacts</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Breadcrumb End -->

        <!-- Contact Section Begin -->
        <section class="contact spad">
            <div class="container">

                <div class="row">
                    <div class="col-lg-4 col-md-4">
                        <div class="contact__widget">
                            <div class="contact__widget__address">
                                <h4>Contact Us</h4>
                                <ul>
                                    <li><i class="fa fa-send"></i> 40 Fareed Town Sreet 133/2 Sahiwal City</li>
                                    <li><i class="fa fa-envelope"></i> alirazach0031@gmail.com</li>
                                    <li><i class="fa fa-phone"></i> +92 302 23 48</li>
                                </ul>
                            </div>
                            <div class="contact__widget__time">
                                <h4>Opening Hours</h4>
                                <ul>
                                    <li><i class="fa fa-clock-o"></i> 24/7 Hours</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8">
                        <form action="#" class="contact__form">
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <input type="text" id="f_name" name="f_name" placeholder="First Name" required="required" pattern="[A-Za-z ]+" title="Your First Name must be contain Only letters">
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <input type="text" id="l_name"  name="l_name" placeholder="Last Name" required="required" pattern="[A-Za-z ]+" title="Your Last Name must be contain Only letters">
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <input type="text" id="email" name="email" placeholder="Your Email i.e. abc123@gmail.com" required="required" data-error="Valid email is required.">
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <input type="tel" id="phone"  name="phone" placeholder="Phone Number i.e. 03116064229" required="required" pattern="[0-9]{11}" maxlength="11" title="Your number must be 11 digits long and contain only numbers">
                                </div>
                            </div>
                            <textarea placeholder="Message" id="msg" name="msg" required="required"></textarea>
                            <button type="submit" onclick="return valid()" name="sub_btn" class="site-btn">SEND MESSAGE</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!-- Contact Section End -->

        <!-- Newslatter Section Begin -->
        <?php
        include 'components/footer.php';
        ?>
        <!-- Footer Section End -->

        <!-- Js Plugins -->
        <script src="js/jquery-3.3.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.nice-select.min.js"></script>
        <script src="js/jquery-ui.min.js"></script>
        <script src="js/jquery.nicescroll.min.js"></script>
        <script src="js/jquery.barfiller.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/jquery.slicknav.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/main.js"></script>
        <script src="toster/toastr.min.js"></script>
        <script>
                                function valid() {
                                    var f_name, l_name, mail, phone, msg;
                                    var temp = 1;
                                    f_name = $('#f_name').val();
                                    msg = $('#msg').val();
                                    l_name = $('#l_name').val();
                                    mail = $('#email').val();
                                    phone = $('#phone').val();
                                    $('#msg').css('border', 'solid 1px grey');
                                    $('#f_name').css('border', 'solid 1px grey');
                                    $('#l_name').css('border', 'solid 1px grey');
                                    $('#phone').css('border', 'solid 1px grey');
                                    $('#email').css('border', 'solid 1px grey');
                                    if (f_name == '') {
                                        $('#f_name').css('border', 'solid 1px red');
                                        temp++;
                                    }
                                    if (l_name == '') {
                                        $('#l_name').css('border', 'solid 1px red');
                                        temp++;
                                    }
                                    if (msg == '') {
                                        $('#msg').css('border', 'solid 1px red');
                                        temp++;
                                    }
                                    if (phone == '') {
                                        $('#phone').css('border', 'solid 1px red');
                                        temp++;
                                    }
                                    if (mail == '') {
                                        $('#email').css('border', 'solid 1px red');
                                        temp++;
                                    }
                                    if (temp != 1) {
                                        return false;
                                    }
                                }

        </script>
        <?php
        if (isset($_GET['sent'])) {
            ?>
            <script type="text/javascript">
                toastr.options = {
                    "closeButton": true,
                    "showMethod": "fadeIn",
                    "hideMethod": "fadeOut"
                }
                toastr.success('Message has been sent!');
            </script>
            <?php
        }
        ?>
    </body>

</html>