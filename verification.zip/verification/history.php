<?php
include 'settings/dbconnect.php';
?>
<!DOCTYPE html>
<html lang="zxx">

    <head>
        <meta charset="UTF-8">
        <meta name="description" content="Directing Template">
        <meta name="keywords" content="Directing, unica, creative, html">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>My Complaints | Verification System</title>

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">

        <!-- Css Styles -->
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
        <link rel="stylesheet" href="css/flaticon.css" type="text/css">
        <link rel="stylesheet" href="css/nice-select.css" type="text/css">
        <link rel="stylesheet" href="css/barfiller.css" type="text/css">
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
        <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
        <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
        <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
        <link rel="stylesheet" href="css/style.css" type="text/css">
        <link rel="stylesheet" type="text/css" href="toster/toastr.min.css">
    </head>
    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        td, th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #dddddd;
        }
    </style>
    <body>
        <!-- Page Preloder -->
        <div id="preloder">
            <div class="loader"></div>
        </div>

        <!-- Header Section Begin -->
        <?php
        include 'components/menu.php';
        ?>
        <!-- Header Section End -->

        <!-- Breadcrumb Begin -->
        <div class="breadcrumb-area set-bg" data-setbg="img/breadcrumb/breadcrumb-normal.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="breadcrumb__text">
                            <h2>My Complaints</h2>
                            <div class="breadcrumb__option">
                                <a href="#"><i class="fa fa-home"></i> Home</a>
                                <span>My Complaints</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Breadcrumb End -->

        <!-- Contact Section Begin -->
        <section class="contact spad">
            <div class="container">

                <div class="row">
                <div class="col-md-12">
                    <h2>History</h2><br>
                </div>
                    <div class="col-lg-12 col-md-12">
                        <table>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>CNIC</th>
                                <th>Phone</th>
                                <th>Category</th>
                                <th>code</th>
                                <th>Status</th>
                            </tr>
                            <?php
                            $q = 'SELECT * FROM `complain` as p INNER JOIN category as c on c.cat_id=p.cat_id inner join reg_user as r on r.user_id=p.user_id WHERE p.user_id=' . $_SESSION['USERID'];
                            $result = mysqli_query($con, $q);
                            if (mysqli_num_rows($result) > 0) {
                                $sr = 1;
                                while ($row = mysqli_fetch_array($result)) {
                                    ?>
                                    <tr>
                                        <td><?= $sr++ . '.' ?></td>
                                        <td><?= $row['name'] ?></td>
                                        <td><?= $row['id_card'] ?></td>
                                        <td><?= $row['phone'] ?></td>
                                        <td><?= $row['cat_name'] ?></td>
                                        <td><?= $row['product_code'] ?></td>
                                        <td><?php
                                            if ($row['mark_status'] == 0) {
                                                echo 'Pending';
                                            } else if ($row['mark_status'] == 1) {
                                                echo 'Approved';
                                            } else if ($row['mark_status'] == 2) {
                                                echo 'Rejected';
                                            } else {
                                                echo 'Cleared';
                                            }
                                            ?></td>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                ?>
                                <tr>
                                    <td colspan="7" >
                                <center>
                                    No Record Found
                                </center>
                                </td>
                                </tr>

                                <?php
                            }
                            ?>
                        </table>
                    </div>
                </div>
            </div>
        </section>
        <!-- Contact Section End -->

        <!-- Newslatter Section Begin -->
        <?php
        include 'components/footer.php';
        ?>
        <!-- Footer Section End -->

        <!-- Js Plugins -->
        <script src="js/jquery-3.3.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.nice-select.min.js"></script>
        <script src="js/jquery-ui.min.js"></script>
        <script src="js/jquery.nicescroll.min.js"></script>
        <script src="js/jquery.barfiller.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/jquery.slicknav.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/main.js"></script>
        <script src="toster/toastr.min.js"></script>

        <?php
        if (isset($_GET['loggedin'])) {
            ?>
            <script type="text/javascript">
                toastr.options = {
                    "closeButton": true,
                    "showMethod": "fadeIn",
                    "hideMethod": "fadeOut"
                }
                toastr.success('Login Successfully!');
            </script>
            <?php
        }
        ?>
        <?php
        if (isset($_GET['complain_sub'])) {
            ?>
            <script type="text/javascript">
                toastr.options = {
                    "closeButton": true,
                    "showMethod": "fadeIn",
                    "hideMethod": "fadeOut"
                }
                toastr.success('Complaint submitted successfully wait for Approval!');
            </script>
            <?php
        }
        ?>
    </body>

</html>