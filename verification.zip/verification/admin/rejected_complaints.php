<?php
include 'settings/dbconnect.php';
if (isset($_GET['delete'])) {
    $q = 'DELETE FROM `complain` WHERE complain_id=' . $_GET['id'];
    mysqli_query($con, $q);
    header('location:rejected_complaints.php?deleted');
}
if (isset($_GET['approve'])) {
    $q = 'UPDATE `complain` SET `mark_status`=1 where complain_id=' . $_GET['id'];
    mysqli_query($con, $q);
    header('location:rejected_complaints.php?approved');
}
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>All Verification List | Verification System</title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
        <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/libs/css/style.css">
        <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
        <link rel="stylesheet" type="text/css" href="assets/vendor/datatables/css/dataTables.bootstrap4.css">
        <link rel="stylesheet" type="text/css" href="assets/vendor/datatables/css/buttons.bootstrap4.css">
        <link rel="stylesheet" type="text/css" href="assets/vendor/datatables/css/select.bootstrap4.css">
        <link rel="stylesheet" type="text/css" href="assets/vendor/datatables/css/fixedHeader.bootstrap4.css">
        <link rel="stylesheet" type="text/css" href="assets/toastr.min.css">
    </head>

    <body>
        <!-- ============================================================== -->
        <!-- main wrapper -->
        <!-- ============================================================== -->
        <div class="dashboard-main-wrapper">
            <!-- ============================================================== -->
            <!-- navbar -->
            <?php
            include 'component/menu.php';
            ?>
            <!-- ============================================================== -->
            <!-- end left sidebar -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- wrapper  -->
            <!-- ============================================================== -->
            <div class="dashboard-wrapper">
                <div class="container-fluid  dashboard-content">
                    <!-- ============================================================== -->
                    <!-- pageheader -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">Rejected Complaints List</h2>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Manage Complaints</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">All Complaints List</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- valifation types -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <div class="card-body">
                                    <form  method="get">
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Search Complaints Status</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                            <select class="form-control" name="cat_id" id="cat_id" onchange="form.submit()">
                                                <option value="0">All</option>
                                                <option value="5" <?php
                                                                    if (isset($_GET['cat_id'])) {
                                                                        if ($_GET['cat_id'] == 5) {
                                                                            echo 'selected=""';
                                                                        }
                                                                    }
                                                                    ?>>Car</option>
                                                <option value="6" <?php
                                                                    if (isset($_GET['cat_id'])) {
                                                                        if ($_GET['cat_id'] == 6) {
                                                                            echo 'selected=""';
                                                                        }
                                                                    }
                                                                    ?>>Bike</option>
                                                <option value="4" <?php
                                                                    if (isset($_GET['cat_id'])) {
                                                                        if ($_GET['cat_id'] == 4) {
                                                                            echo 'selected=""';
                                                                        }
                                                                    }
                                                                    ?>>Mobile</option>
                                            </select>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end valifation types -->
                        <!-- ============================================================== -->
                    </div>
                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- data table  -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="mb-0">Rejected Complaints</h5>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="example" class="table table-striped table-bordered second" style="width:100%">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Name</th>
                                                    <th>Phone</th>
                                                    <th>CNIC</th>
                                                    <th>Category</th>
                                                    <th>Code</th>
                                                    <th>Description</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                if(isset($_GET['cat_id'])){
                                                    if($_GET['cat_id']){
                                                        $query = 'SELECT * FROM `complain` as c INNER JOIN category as ct on c.cat_id=ct.cat_id INNER JOIN reg_user as ru on ru.user_id=c.user_id where c.mark_status=2 and c.cat_id='.$_GET['cat_id'];
                                                    }else{
                                                        $query = 'SELECT * FROM `complain` as c INNER JOIN category as ct on c.cat_id=ct.cat_id INNER JOIN reg_user as ru on ru.user_id=c.user_id where c.mark_status=2';
                                                    }
                                                }else{
                                                    $query = 'SELECT * FROM `complain` as c INNER JOIN category as ct on c.cat_id=ct.cat_id INNER JOIN reg_user as ru on ru.user_id=c.user_id where c.mark_status=2';
                                                }
                                               

                                                $result = mysqli_query($con, $query);
                                                if (mysqli_num_rows($result) > 0) {
                                                    $sr = 1;
                                                    while ($row = mysqli_fetch_array($result)) {
                                                        ?>
                                                        <tr>
                                                            <td><?= $sr . '.' ?></td>
                                                            <td><?= $row['name'] ?></td>
                                                            <td><?= $row['phone'] ?></td>
                                                            <td><?= $row['id_card'] ?></td>
                                                            <td><?= $row['cat_name'] ?></td>
                                                            <td><?= $row['product_code'] ?></td>
                                                            <td><?= $row['complain_description'] ?></td>

                                                            <td>

                                                                <a href="complaints/<?= $row['proof_img'] ?>" target="_blank" class="btn btn-info">View Image</a>
                                                                <a href = "rejected_complaints.php?approve&id=<?= $row['complain_id'] ?>" class = "btn btn-success">Approve</a>
                                                                <a href = "rejected_complaints.php?delete&id=<?= $row['complain_id'] ?>" onclick = "return warning()" class = "btn btn-danger">Delete</a>
                                                            </td>
                                                        </tr>
                                                        <?php
                                                        $sr++;
                                                    }
                                                } else {
                                                    ?>
                                                    <tr >
                                                        <td colspan="8"><center>No Rejected Complains Found</center></td>
                                                </tr>
                                                <?php
                                            }
                                            ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Name</th>
                                                    <th>Phone</th>
                                                    <th>CNIC</th>
                                                    <th>Category</th>
                                                    <th>Code</th>
                                                    <th>Description</th>
                                                    <th>Action</th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end data table  -->
                        <!-- ============================================================== -->
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- footer -->
                <!-- ============================================================== -->

                <!-- ============================================================== -->
                <!-- end footer -->
                <!-- ============================================================== -->
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end main wrapper -->
        <!-- ============================================================== -->
        <!-- Optional JavaScript -->
        <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
        <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
        <script src="assets/vendor/multi-select/js/jquery.multi-select.js"></script>
        <script src="assets/libs/js/main-js.js"></script>
        <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
        <script src="assets/vendor/datatables/js/dataTables.bootstrap4.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
        <script src="assets/vendor/datatables/js/buttons.bootstrap4.min.js"></script>
        <script src="assets/toastr.min.js"></script>
        <script src="assets/vendor/datatables/js/data-table.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.colVis.min.js"></script>
        <script src="https://cdn.datatables.net/rowgroup/1.0.4/js/dataTables.rowGroup.min.js"></script>
        <script src="https://cdn.datatables.net/select/1.2.7/js/dataTables.select.min.js"></script>
        <script src="https://cdn.datatables.net/fixedheader/3.1.5/js/dataTables.fixedHeader.min.js"></script>
        <script>

                                                            function warning() {
                                                                if (confirm(" Are you Sure you want to delete this complain?")) {
                                                                    return true;
                                                                } else {
                                                                    return false;
                                                                }
                                                            }
        </script>

        <?php
        if (isset($_GET['deleted'])) {
            ?>
            <script type="text/javascript">
                toastr.options = {
                    "closeButton": true,
                    "showMethod": "fadeIn",
                    "hideMethod": "fadeOut"
                }
                toastr.error('Complain Deleted!');
            </script>
            <?php
        }
        ?>
        <?php
        if (isset($_GET['approved'])) {
            ?>
            <script type="text/javascript">
                toastr.options = {
                    "closeButton": true,
                    "showMethod": "fadeIn",
                    "hideMethod": "fadeOut"
                }
                toastr.success('Complain Approved!');
            </script>
            <?php
        }
        ?>

    </body>

</html>