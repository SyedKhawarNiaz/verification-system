<?php

$con = mysqli_connect('localhost', 'root', '', 'verify');
if ($con) {
    session_start();
//    echo 'Connection Established';
} else {
    echo 'Error Connection';
}
?>