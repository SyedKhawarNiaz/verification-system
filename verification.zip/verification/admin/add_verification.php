<?php
include 'settings/dbconnect.php';
if (isset($_REQUEST['sub_btn'])) {
    //check already added
    $chcek_query = 'SELECT * FROM `complain` where `product_code`="' . $_REQUEST['code'] . '" && cat_id="' . $_REQUEST['category'] . '"';
    $result = mysqli_query($con, $chcek_query);
    if (mysqli_num_rows($result) > 0) {
        header('location:add_verification.php?already_added');
    } else {
        $path = $_FILES["img"]["name"];
        $query = 'INSERT INTO `complain`(`user_id`,`cat_id`, `product_code`, `complain_description`, `proof_img`, `complain_status`) VALUES ("' . $_SESSION['USERID'] . '","' . $_REQUEST['category'] . '","' . $_REQUEST['code'] . '","' . $_REQUEST['msg'] . '","' . $path . '","' . $_REQUEST['status'] . '")';
//    die($query);
        move_uploaded_file($_FILES["img"]["tmp_name"], "admin/complaints/" . $_FILES["img"]["name"]);
        mysqli_query($con, $query);
        header('location:add_verification.php?added');
    }
}
?>
<!doctype html>
<html lang="en">


    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Add New Complaint</title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
        <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
        <link rel="stylesheet" href="assets/libs/css/style.css">
        <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
        <link rel="stylesheet" href="assets/toastr.min.css">
    </head>

    <body>
        <!-- ============================================================== -->
        <!-- main wrapper -->
        <!-- ============================================================== -->
        <div class="dashboard-main-wrapper">
            <!-- ============================================================== -->
            <!-- navbar -->
            <!-- ============================================================== -->
            <?php
            include 'component/menu.php';
            ?>
            <!-- ============================================================== -->
            <!-- end left sidebar -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- wrapper  -->
            <!-- ============================================================== -->
            <div class="dashboard-wrapper">
                <div class="container-fluid  dashboard-content">
                    <!-- ============================================================== -->
                    <!-- pageheader -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h2 class="pageheader-title">Add New Complaint</h2>
                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Dashboard</a></li>
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">Manage Complaints</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Add New Complaint</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end pageheader -->
                    <!-- ============================================================== -->

                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- valifation types -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">New Complaint Form</h5>
                                <div class="card-body">
                                    <form method="post">
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Select Category</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <select class="form-control" id="cat" name="cat" onchange="return placeholder()">
                                                    <option value="0">Select Category</option>
                                                    <?php
                                                    $query = 'SELECT * FROM `category` WHERE cat_status=1';
                                                    $result = mysqli_query($con, $query);
                                                    if (mysqli_num_rows($result) > 0) {
                                                        while ($row = mysqli_fetch_array($result)) {
                                                            ?>
                                                            <option value="<?= $row['cat_id'] ?>"><?= $row['cat_name'] ?></option>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Status</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <select class="form-control" id="status" name="status" >
                                                    <option value="0">Select Status</option>
                                                    <option value="3">Stolen</option>
                                                    <option value="2">Lost</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Product Code</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="text" required=""  name="code" id="code" placeholder="Enter Product Specific code" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Complaint Description</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <textarea type="text" required=""  name="desc" id="desc" placeholder="Description" class="form-control"></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-12 col-sm-3 col-form-label text-sm-right">Proof Picture</label>
                                            <div class="col-12 col-sm-8 col-lg-6">
                                                <input type="file" required=""  name="img" id="img" class="form-control">
                                            </div>
                                        </div>

                                        <div class="form-group row text-right">
                                            <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                                                <button type="submit" name="sub_btn" onclick="return valid()" class="btn btn-space btn-primary">Submit</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end valifation types -->
                        <!-- ============================================================== -->
                    </div>

                </div>
                <!-- ============================================================== -->
                <!-- footer -->
                <!-- ============================================================== -->

                <!-- ============================================================== -->
                <!-- end footer -->
                <!-- ============================================================== -->
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end main wrapper -->
        <!-- ============================================================== -->
        <!-- Optional JavaScript -->
        <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
        <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
        <script src="assets/vendor/parsley/parsley.js"></script>
        <script src="assets/libs/js/main-js.js"></script>
        <script src="assets/toastr.min.js"></script>
        <script>
                                                    function valid() {
                                                        var cat, code, status, desc, img;
                                                        var temp = 1;
                                                        cat = $('#cat').val();
                                                        code = $('#code').val();
                                                        status = $('#status').val();
                                                        desc = $('#desc').val();
                                                        img = $('#img').val();
                                                        $('#cat').css('border', 'solid 1px grey');
                                                        $('#code').css('border', 'solid 1px grey');
                                                        $('#status').css('border', 'solid 1px grey');
                                                        $('#desc').css('border', 'solid 1px grey');
                                                        $('#img').css('border', 'solid 1px grey');
                                                        if (cat == 0) {
                                                            $('#cat').css('border', 'solid 1px red');
                                                            temp++;
                                                        }
                                                        if (code == '') {
                                                            $('#code').css('border', 'solid 1px red');
                                                            temp++;
                                                        }
                                                        if (status == 0) {
                                                            $('#status').css('border', 'solid 1px red');
                                                            temp++;
                                                        }
                                                        if (desc == '') {
                                                            $('#desc').css('border', 'solid 1px red');
                                                            temp++;
                                                        }
                                                        if (img == '') {
                                                            $('#img').css('border', 'solid 1px red');
                                                            temp++;
                                                        }
                                                        if (temp != 1) {
                                                            return false;
                                                        }
                                                    }
        </script>
        <script>
            function placeholder() {
                var cat = $('#cat').val();
                if (cat == 4) {
                    $("#code").attr("placeholder", "Enter 15 digits IMEI Of Mobile").val("").focus().blur();
                    $("#code").attr("pattern", "[0-9]{15}").val("").focus().blur();
                    $("#code").attr("maxlength", "15").val("").focus().blur();
                }
                if (cat == 5) {
                    $("#code").attr("placeholder", "Enter 17 digits Car Chassis Number").val("").focus().blur();
                    $("#code").attr("pattern", "[A-Z0-9]{17}").val("").focus().blur();
                    $("#code").attr("maxlength", "17").val("").focus().blur();
                }
                if (cat == 6) {
                    $("#code").attr("placeholder", "Enter 17 digits Bike Chassis Number").val("").focus().blur();
                    $("#code").attr("pattern", "[A-Z0-9]{17}").val("").focus().blur();
                    $("#code").attr("maxlength", "17").val("").focus().blur();
                }
            }
        </script>
        <script>
            $('#form').parsley();
        </script>
        <script>
            // Example starter JavaScript for disabling form submissions if there are invalid fields
            (function () {
                'use strict';
                window.addEventListener('load', function () {
                    // Fetch all the forms we want to apply custom Bootstrap validation styles to
                    var forms = document.getElementsByClassName('needs-validation');
                    // Loop over them and prevent submission
                    var validation = Array.prototype.filter.call(forms, function (form) {
                        form.addEventListener('submit', function (event) {
                            if (form.checkValidity() === false) {
                                event.preventDefault();
                                event.stopPropagation();
                            }
                            form.classList.add('was-validated');
                        }, false);
                    });
                }, false);
            })();
        </script>
        <?php
        if (isset($_GET['already_added'])) {
            ?>
            <script type="text/javascript">
                toastr.options = {
                    "closeButton": true,
                    "showMethod": "fadeIn",
                    "hideMethod": "fadeOut"
                }
                toastr.error('Complaint Already submitted!');
            </script>
            <?php
        }
        ?>
        <?php
        if (isset($_GET['added'])) {
            ?>
            <script type="text/javascript">
                toastr.options = {
                    "closeButton": true,
                    "showMethod": "fadeIn",
                    "hideMethod": "fadeOut"
                }
                toastr.success('Complaint submitted successfully wait for Approval!');
            </script>
            <?php
        }
        ?>
    </body>

</html>